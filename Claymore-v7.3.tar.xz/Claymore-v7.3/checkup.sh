#!/bin/bash

# Check if gedit is running
if pgrep "ethdcrminer64" > /dev/null
then
    echo "ethdcrminer64 is running, nothing to do..."
else
    shutdown -r now
fi
