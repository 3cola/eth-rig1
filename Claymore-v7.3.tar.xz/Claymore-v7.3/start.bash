GPU_FORCE_64BIT_PTR=0
GPU_MAX_HEAP_SIZE=100
GPU_USE_SYNC_OBJECTS=1
GPU_MAX_ALLOC_PERCENT=100
GPU_SINGLE_ALLOC_PERCENT=100

# Full auto
/root/Claymore-v7.3/ethdcrminer64

# primary config
# ./ethdcrminer64 -epool eu1.ethermine.org:4444 -ewal 0xfc2b7dd0b652bdd4a325e3984aab8f9cf0cad7e5.Rig1 -epsw x -etha 2 -esm 1 -dpool stratum+tcp://yiimp.ccminer.org:4252 -dwal DsnFxFqjX2fF9AKdkx1eYkAx2c55muykchP -dpsw x 

# secondary config
#./ethdcrminer64 -epool eu1.ethpool.org:3333 -ewal 0xfc2b7dd0b652bdd4a325e3984aab8f9cf0cad7e5.Rig1 -epsw x -etha 2 -esm 1 -dpool stratum+tcp://yiimp.ccminer.org:4252 -dwal DsnFxFqjX2fF9AKdkx1eYkAx2c55muykchP -dpsw x 

# failover config
# ./ethdcrminer64 -epool eth.pool.mn:3333 -ewal 3cola.eth1 -epsw x -etha 2 -esm 3 -allpools 1 -allcoins 1 -dpool stratum+tcp://dcr.pool.mn:2255 -dwal 3cola.dcr1 -dpsw x 

